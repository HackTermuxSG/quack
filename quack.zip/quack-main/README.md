quack
Quack-Toolkit (entynetproject)

ALERT
Copy of the tool (Quack-Toolkit) I am not the programmer of this tool.

INSTALACIÓN
chmod 777 quack.sh

USO
./quack.sh

Created by: _.Soy_Bastian._
